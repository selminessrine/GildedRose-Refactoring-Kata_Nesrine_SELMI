package com.gildedrose;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class GildedRoseTest {

    private GildedRose app;
    private Item[] items;

    // Initialisation des tests
    @BeforeEach
    void setUp() {
        items = new Item[] {
            new Item("+5 Dexterity Vest", 10, 20),
            new Item("Aged Brie", 2, 0),
            new Item("Elixir of the Mongoose", 5, 7),
            new Item("Sulfuras, Hand of Ragnaros", 0, 80),
            new Item("Sulfuras, Hand of Ragnaros", -1, 80),
            new Item("Backstage passes to a TAFKAL80ETC concert", 15, 20),
            new Item("Conjured Mana Cake", 3, 6)
        };
        app = new GildedRose(items);
    }

    @Test
    void testRegularItemQualityDecreases() {
        // Test pour un article normal
        Item item = items[0];  // "+5 Dexterity Vest"
        int initialQuality = item.quality;
        app.updateQuality();
        assertEquals(initialQuality - 1, item.quality);
    }

    @Test
    void testAgedBrieQualityIncreases() {
        // Test pour "Aged Brie"
        Item item = items[1];  // "Aged Brie"
        int initialQuality = item.quality;
        app.updateQuality();
        assertEquals(initialQuality + 1, item.quality);
    }

    @Test
    void testBackstagePassesQualityIncreases() {
        // Test pour "Backstage passes to a TAFKAL80ETC concert"
        Item item = items[5];  // "Backstage passes"
        int initialQuality = item.quality;
        item.sellIn = 10;  // Avant 11 jours
        app.updateQuality();
        assertEquals(initialQuality + 2, item.quality);
    }

    @Test
    void testSulfurasDoesNotChange() {
        // Test pour "Sulfuras, Hand of Ragnaros"
        Item item = items[3];  // "Sulfuras"
        int initialQuality = item.quality;
        int initialSellIn = item.sellIn;
        app.updateQuality();
        assertEquals(initialQuality, item.quality);
        assertEquals(initialSellIn, item.sellIn);
    }

    @Test
    void testConjuredItemsDegradeFaster() {
        // Test pour "Conjured Mana Cake"
        Item item = items[8];  // "Conjured Mana Cake"
        int initialQuality = item.quality;
        app.updateQuality();
        assertEquals(initialQuality - 2, item.quality);  // "Conjured" items degrade de 2
    }

    @Test
    void testExpiredItemsQualityDrops() {
        // Test pour un article expiré
        Item item = items[0];  // "+5 Dexterity Vest"
        item.sellIn = 0;  // Expiré
        int initialQuality = item.quality;
        app.updateQuality();
        assertEquals(initialQuality - 2, item.quality);  // La qualité diminue de 2 après expiration
    }
}
