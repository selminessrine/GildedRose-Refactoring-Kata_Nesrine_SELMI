package com.gildedrose;

class GildedRose {
    Item[] items;

    public GildedRose(Item[] items) {
        this.items = items;
    }

    public void updateQuality() {
        for (Item item : items) {
            updateSellIn(item);
            updateQualityForItem(item);
            if (item.sellIn < 0) {
                updateQualityAfterExpiration(item);
            }
        }
    }

    private void updateSellIn(Item item) {
        // Réduit le sellIn sauf pour "Sulfuras"
        if (!item.name.equals("Sulfuras, Hand of Ragnaros")) {
            item.sellIn--;
        }
    }

    private void updateQualityForItem(Item item) {
        // Met à jour la qualité des articles avant expiration
        if (item.name.equals("Aged Brie")) {
            updateAgedBrieQuality(item);
        } else if (item.name.equals("Backstage passes to a TAFKAL80ETC concert")) {
            updateBackstagePassesQuality(item);
        } else if (item.name.equals("Sulfuras, Hand of Ragnaros")) {
            // Ne fait rien pour Sulfuras, la qualité et le sellIn ne changent pas
        } else if (item.name.equals("Conjured Mana Cake")) {
            updateConjuredItemQuality(item);
        } else {
            updateNormalItemQuality(item);
        }
    }

    private void updateAgedBrieQuality(Item item) {
        // "Aged Brie" augmente en qualité, mais pas au-dessus de 50
        if (item.quality < 50) {
            item.quality++;
        }
    }

    private void updateBackstagePassesQuality(Item item) {
        // Les "Backstage passes" augmentent en qualité selon les règles
        if (item.quality < 50) {
            item.quality++;
            if (item.sellIn < 11) {
                if (item.quality < 50) item.quality++;
            }
            if (item.sellIn < 6) {
                if (item.quality < 50) item.quality++;
            }
        }
    }

    private void updateConjuredItemQuality(Item item) {
        // Les "Conjured" items perdent 2 points de qualité
        if (item.quality > 0) {
            item.quality -= 2;
        }
    }

    private void updateNormalItemQuality(Item item) {
        // Les items "normaux" perdent 1 point de qualité (à condition que ce ne soit pas déjà 0)
        if (item.quality > 0) {
            item.quality--;
        }
    }

    private void updateQualityAfterExpiration(Item item) {
        // Lorsque l'item est expiré, la qualité change selon des règles spécifiques
        if (item.name.equals("Aged Brie")) {
            // "Aged Brie" continue d'augmenter en qualité
            if (item.quality < 50) {
                item.quality++;
            }
        } else if (item.name.equals("Backstage passes to a TAFKAL80ETC concert")) {
            // "Backstage passes" perdent toute leur qualité après expiration
            item.quality = 0;
        } else if (item.quality > 0 && !item.name.equals("Sulfuras, Hand of Ragnaros")) {
            // Les autres items perdent 1 point de qualité après expiration
            item.quality--;
        }
    }
}
